import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ProductTest {

    @Test
    void testToCSVDataRecord() {
        Product product = new Product("Computer", "Apple computer", "000001", 999.99);
        assertEquals("000001,Computer,Apple computer,999.99", product.toCSVDataRecord());
    }
}

