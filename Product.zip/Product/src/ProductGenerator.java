import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Scanner;

import static java.nio.file.StandardOpenOption.CREATE;

public class ProductGenerator {
    public static void main(String[] args) {
        String name, description, ID;
        double cost;
        String csvRec;
        boolean done = false;

        Scanner in = new Scanner(System.in);

        ArrayList<String> recs = new ArrayList<>();

        do {
            name = SafeInput.getNonZeroLenString(in, "Enter the name of the product ");
            description = SafeInput.getNonZeroLenString(in, "Enter the description ");
            ID = SafeInput.getNonZeroLenString(in, "Enter your ID number ");
            cost = SafeInput.getRangedDouble(in, "Enter the cost ", 0, 1000000);

            csvRec = name + ", " + description + ", " + ID + ", " + cost;

            recs.add(csvRec);

            done = SafeInput.getYNConfirm(in, "Are you done? ");
        } while (!done);

        Path file = Paths.get("src", "data.txt");

        try (BufferedWriter writer = Files.newBufferedWriter(file, CREATE)) {
            for (String record : recs) {
                writer.write(record);
                writer.newLine();
            }
            System.out.println("Data written to file: " + file.toAbsolutePath());
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
