import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PersonTest {

    @Test
    void testGetFullName()
    {
        Person person = new Person("000001", "Macy", "Debord", "Ms.", 2002);
        assertEquals("Macy Debord", person.getFullName());
    }

    @Test
    void testGetFormalName()
    {
        Person person = new Person("000001", "Macy", "Debord", "Ms.", 2002);
        assertEquals("Ms. Macy Debord", person.getFormalName());
    }

    @Test
    void testToCSVDataRecord() {

        Person person = new Person("000001", "Macy", "Debord", "Ms.", 2002);
        assertEquals("000001, Macy, Debord, Ms., 2002", person.toCSVDataRecord());
    }

    @Test
    void testGetAge()
    {
        Person person = new Person("000001", "Macy", "Debord", "Ms.", 2002);
        int currentYear = java.util.Calendar.getInstance().get(java.util.Calendar.YEAR);
        assertEquals(currentYear - 2002, person.getAge());
    }

    @Test
    void testGetAgeTwo()
    {
        Person person = new Person("000001", "Macy", "Debord", "Ms.", 2002);
        int specifiedYear = 2024;
        assertEquals(specifiedYear - 2002, person.getAge(specifiedYear));
    }
}

